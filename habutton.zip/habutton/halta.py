import os
import random
import tkinter as tk

from playsound import playsound
from pynput.mouse import Listener, Button


i = 0
ones_place = 0
tens_place = 0
path = './'
full_path = os.path.abspath(path)
img_path = f'{full_path}/pict'
voice_path = f'{full_path}/voice'


def main():
    #画像を表示
    cvs.create_image(300, 300, image=img[1], tag='switch')
    cvs.create_image(300, 300, image=img[0], tag='bg')
    cvs.create_image(345, 430, image=num[0], tag='ones_place')

def left_click(e):
    #左クリック時のスイッチを上下に移動させてcounterを呼び出し
    for i in range(1, 11):
        cvs.move("switch", 0, i)
        cvs.update()
    for i in range(-1, -11, -1):
        cvs.move("switch", 0, i)
        cvs.update()
    counter(full_path)

def roulette():
    #音声を抽選
    num = random.randint(0, 98)
    if num == 0:
        voice = 'rin_pre.wav'
    elif 1 <= num <= 49:
        voice = 'kona.wav'
    else:
        voice = 'kan.wav'

    return voice

def counter(full_path):
        #カウンター
        global i, img, ones_place, tens_place
        voice_file = roulette()
        voice = f'{voice_path}/{voice_file}'
        i += 1
        ones_place += 1
        #桁上げ処理
        if ones_place == 10 and tens_place == 0:
            ones_place = 0
            tens_place = 1
            cvs.create_image(270, 430, image=num[tens_place], tag='tens_place')
        elif ones_place == 10 and tens_place == 1:
            ones_place = 0
            tens_place = 2
            cvs.delete("tens_place")
            cvs.create_image(270, 430, image=num[tens_place], tag='tens_place')
        cvs.delete("ones_place")
        cvs.create_image(345, 430, image=num[ones_place], tag='ones_place')
        #初回の処理
        if i == 1:
            img[0] = tk.PhotoImage(file=f'{img_path}/base_on.png')
            cvs.delete("bg")
            cvs.create_image(300, 300, image=img[0], tag='bg')
            cvs.delete("ones_place")
            cvs.create_image(345, 430, image=num[ones_place], tag='ones_place')
            voice
        #21回目でリセット
        if i == 21:
            voice = f'{voice_path}/reset.wav'
            global init
            i = 0
            img[0] = tk.PhotoImage(file=f'{img_path}/base.png')
            cvs.delete("bg")
            cvs.create_image(300, 300, image=img[0], tag='bg')
            ones_place = 0
            tens_place = ''
            cvs.delete("ones_place")
            cvs.create_image(345, 430, image=num[ones_place], tag='ones_place')
            cvs.delete("tens_place")
        elif i < 21:
            voice
        playsound(voice)

root = tk.Tk()
cvs = tk.Canvas(width=600, height=600)
cvs.pack()
#背景、スイッチ画像
img = [
    tk.PhotoImage(file=f'{img_path}/base.png'),
    tk.PhotoImage(file=f'{img_path}/switch.png')
]
#セグ画像
num = [tk.PhotoImage(file=f'{img_path}/{i}.png') for i in range(10)]
main()
cvs.bind('<Button-1>', left_click)
root.title('ハッ！ボタン')
root.mainloop()